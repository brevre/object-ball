console.log('Simple debugging example running.')
debugger

let x = 99
debugger
console.log(x)
